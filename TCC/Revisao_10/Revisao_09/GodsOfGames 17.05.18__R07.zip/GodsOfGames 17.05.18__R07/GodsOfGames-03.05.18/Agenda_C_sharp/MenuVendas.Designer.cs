﻿namespace Agenda_C_sharp
{
    partial class MenuVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuVendas));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtClienteMenuVenda = new System.Windows.Forms.TextBox();
            this.txtDataMenuVenda = new System.Windows.Forms.TextBox();
            this.txtNMenuVenda = new System.Windows.Forms.TextBox();
            this.lblClienteMenuVenda = new System.Windows.Forms.Label();
            this.lblDataMenuVenda = new System.Windows.Forms.Label();
            this.lblNMenuVenda = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtSubTotalMenuVenda = new System.Windows.Forms.TextBox();
            this.lblSubTotalMenuVenda = new System.Windows.Forms.Label();
            this.txtQuantidadeMenuVenda = new System.Windows.Forms.TextBox();
            this.lblQuantidadeMenuVenda = new System.Windows.Forms.Label();
            this.txtPrecoMenuVenda = new System.Windows.Forms.TextBox();
            this.txtDescricaoMenuVenda = new System.Windows.Forms.TextBox();
            this.txtCodigoMenuVenda = new System.Windows.Forms.TextBox();
            this.lblPrecoMenuVenda = new System.Windows.Forms.Label();
            this.lblDescricaoMenuVenda = new System.Windows.Forms.Label();
            this.lblCodigoMenuVenda = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblValorFinalMenuVenda = new System.Windows.Forms.Label();
            this.lblDescontoMenuVenda = new System.Windows.Forms.Label();
            this.lblTaxasMenuVenda = new System.Windows.Forms.Label();
            this.lblTotalMenuVenda = new System.Windows.Forms.Label();
            this.txtValorFinalMenuVenda = new System.Windows.Forms.TextBox();
            this.txtDescontoMenuVenda = new System.Windows.Forms.TextBox();
            this.txtTaxasMenuVenda = new System.Windows.Forms.TextBox();
            this.txtTotalMenuVenda = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtClienteMenuVenda);
            this.groupBox1.Controls.Add(this.txtDataMenuVenda);
            this.groupBox1.Controls.Add(this.txtNMenuVenda);
            this.groupBox1.Controls.Add(this.lblClienteMenuVenda);
            this.groupBox1.Controls.Add(this.lblDataMenuVenda);
            this.groupBox1.Controls.Add(this.lblNMenuVenda);
            this.groupBox1.Location = new System.Drawing.Point(12, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(810, 76);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pesquisar";
            // 
            // txtClienteMenuVenda
            // 
            this.txtClienteMenuVenda.Location = new System.Drawing.Point(565, 33);
            this.txtClienteMenuVenda.Name = "txtClienteMenuVenda";
            this.txtClienteMenuVenda.Size = new System.Drawing.Size(220, 20);
            this.txtClienteMenuVenda.TabIndex = 5;
            // 
            // txtDataMenuVenda
            // 
            this.txtDataMenuVenda.Location = new System.Drawing.Point(333, 33);
            this.txtDataMenuVenda.Name = "txtDataMenuVenda";
            this.txtDataMenuVenda.Size = new System.Drawing.Size(103, 20);
            this.txtDataMenuVenda.TabIndex = 4;
            // 
            // txtNMenuVenda
            // 
            this.txtNMenuVenda.Location = new System.Drawing.Point(80, 33);
            this.txtNMenuVenda.Multiline = true;
            this.txtNMenuVenda.Name = "txtNMenuVenda";
            this.txtNMenuVenda.Size = new System.Drawing.Size(78, 20);
            this.txtNMenuVenda.TabIndex = 3;
            // 
            // lblClienteMenuVenda
            // 
            this.lblClienteMenuVenda.AutoSize = true;
            this.lblClienteMenuVenda.Location = new System.Drawing.Point(516, 36);
            this.lblClienteMenuVenda.Name = "lblClienteMenuVenda";
            this.lblClienteMenuVenda.Size = new System.Drawing.Size(42, 13);
            this.lblClienteMenuVenda.TabIndex = 2;
            this.lblClienteMenuVenda.Text = "Cliente:";
            // 
            // lblDataMenuVenda
            // 
            this.lblDataMenuVenda.AutoSize = true;
            this.lblDataMenuVenda.Location = new System.Drawing.Point(264, 36);
            this.lblDataMenuVenda.Name = "lblDataMenuVenda";
            this.lblDataMenuVenda.Size = new System.Drawing.Size(60, 13);
            this.lblDataMenuVenda.TabIndex = 1;
            this.lblDataMenuVenda.Text = "Data Atual:";
            // 
            // lblNMenuVenda
            // 
            this.lblNMenuVenda.AutoSize = true;
            this.lblNMenuVenda.Location = new System.Drawing.Point(12, 36);
            this.lblNMenuVenda.Name = "lblNMenuVenda";
            this.lblNMenuVenda.Size = new System.Drawing.Size(63, 13);
            this.lblNMenuVenda.TabIndex = 0;
            this.lblNMenuVenda.Text = "N° da Nota:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.txtSubTotalMenuVenda);
            this.groupBox2.Controls.Add(this.lblSubTotalMenuVenda);
            this.groupBox2.Controls.Add(this.txtQuantidadeMenuVenda);
            this.groupBox2.Controls.Add(this.lblQuantidadeMenuVenda);
            this.groupBox2.Controls.Add(this.txtPrecoMenuVenda);
            this.groupBox2.Controls.Add(this.txtDescricaoMenuVenda);
            this.groupBox2.Controls.Add(this.txtCodigoMenuVenda);
            this.groupBox2.Controls.Add(this.lblPrecoMenuVenda);
            this.groupBox2.Controls.Add(this.lblDescricaoMenuVenda);
            this.groupBox2.Controls.Add(this.lblCodigoMenuVenda);
            this.groupBox2.Location = new System.Drawing.Point(12, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(810, 119);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Produto";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(729, 85);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Gravar";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(726, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(43, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "Gravar";
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // txtSubTotalMenuVenda
            // 
            this.txtSubTotalMenuVenda.Location = new System.Drawing.Point(306, 76);
            this.txtSubTotalMenuVenda.Name = "txtSubTotalMenuVenda";
            this.txtSubTotalMenuVenda.Size = new System.Drawing.Size(103, 20);
            this.txtSubTotalMenuVenda.TabIndex = 9;
            // 
            // lblSubTotalMenuVenda
            // 
            this.lblSubTotalMenuVenda.AutoSize = true;
            this.lblSubTotalMenuVenda.Location = new System.Drawing.Point(240, 83);
            this.lblSubTotalMenuVenda.Name = "lblSubTotalMenuVenda";
            this.lblSubTotalMenuVenda.Size = new System.Drawing.Size(56, 13);
            this.lblSubTotalMenuVenda.TabIndex = 8;
            this.lblSubTotalMenuVenda.Text = "Sub Total:";
            // 
            // txtQuantidadeMenuVenda
            // 
            this.txtQuantidadeMenuVenda.Location = new System.Drawing.Point(81, 76);
            this.txtQuantidadeMenuVenda.Name = "txtQuantidadeMenuVenda";
            this.txtQuantidadeMenuVenda.Size = new System.Drawing.Size(78, 20);
            this.txtQuantidadeMenuVenda.TabIndex = 7;
            // 
            // lblQuantidadeMenuVenda
            // 
            this.lblQuantidadeMenuVenda.AutoSize = true;
            this.lblQuantidadeMenuVenda.Location = new System.Drawing.Point(12, 80);
            this.lblQuantidadeMenuVenda.Name = "lblQuantidadeMenuVenda";
            this.lblQuantidadeMenuVenda.Size = new System.Drawing.Size(65, 13);
            this.lblQuantidadeMenuVenda.TabIndex = 6;
            this.lblQuantidadeMenuVenda.Text = "Quantidade:";
            // 
            // txtPrecoMenuVenda
            // 
            this.txtPrecoMenuVenda.Location = new System.Drawing.Point(518, 33);
            this.txtPrecoMenuVenda.Name = "txtPrecoMenuVenda";
            this.txtPrecoMenuVenda.Size = new System.Drawing.Size(95, 20);
            this.txtPrecoMenuVenda.TabIndex = 5;
            // 
            // txtDescricaoMenuVenda
            // 
            this.txtDescricaoMenuVenda.Location = new System.Drawing.Point(306, 33);
            this.txtDescricaoMenuVenda.Name = "txtDescricaoMenuVenda";
            this.txtDescricaoMenuVenda.Size = new System.Drawing.Size(103, 20);
            this.txtDescricaoMenuVenda.TabIndex = 4;
            // 
            // txtCodigoMenuVenda
            // 
            this.txtCodigoMenuVenda.Location = new System.Drawing.Point(81, 33);
            this.txtCodigoMenuVenda.Name = "txtCodigoMenuVenda";
            this.txtCodigoMenuVenda.Size = new System.Drawing.Size(78, 20);
            this.txtCodigoMenuVenda.TabIndex = 3;
            // 
            // lblPrecoMenuVenda
            // 
            this.lblPrecoMenuVenda.AutoSize = true;
            this.lblPrecoMenuVenda.Location = new System.Drawing.Point(474, 36);
            this.lblPrecoMenuVenda.Name = "lblPrecoMenuVenda";
            this.lblPrecoMenuVenda.Size = new System.Drawing.Size(38, 13);
            this.lblPrecoMenuVenda.TabIndex = 2;
            this.lblPrecoMenuVenda.Text = "Preço:";
            // 
            // lblDescricaoMenuVenda
            // 
            this.lblDescricaoMenuVenda.AutoSize = true;
            this.lblDescricaoMenuVenda.Location = new System.Drawing.Point(240, 36);
            this.lblDescricaoMenuVenda.Name = "lblDescricaoMenuVenda";
            this.lblDescricaoMenuVenda.Size = new System.Drawing.Size(58, 13);
            this.lblDescricaoMenuVenda.TabIndex = 1;
            this.lblDescricaoMenuVenda.Text = "Descrição:";
            // 
            // lblCodigoMenuVenda
            // 
            this.lblCodigoMenuVenda.AutoSize = true;
            this.lblCodigoMenuVenda.Location = new System.Drawing.Point(12, 36);
            this.lblCodigoMenuVenda.Name = "lblCodigoMenuVenda";
            this.lblCodigoMenuVenda.Size = new System.Drawing.Size(43, 13);
            this.lblCodigoMenuVenda.TabIndex = 0;
            this.lblCodigoMenuVenda.Text = "Código:";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.pictureBox3);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(12, 272);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(810, 210);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Faturas";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(706, 177);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "Deleta Tudo";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(719, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 13);
            this.label14.TabIndex = 11;
            this.label14.Text = "Deleta";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(716, 129);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(43, 45);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "Gravar";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(715, 44);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(43, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "Gravar";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(640, 177);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.pictureBox5);
            this.groupBox4.Controls.Add(this.pictureBox4);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Location = new System.Drawing.Point(12, 500);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(395, 156);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Ações";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(253, 100);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "PrintNF";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(253, 48);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(43, 45);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Tag = "Gravar";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(101, 48);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(43, 45);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "Gravar";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(101, 100);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Finalizar";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblValorFinalMenuVenda);
            this.groupBox5.Controls.Add(this.lblDescontoMenuVenda);
            this.groupBox5.Controls.Add(this.lblTaxasMenuVenda);
            this.groupBox5.Controls.Add(this.lblTotalMenuVenda);
            this.groupBox5.Controls.Add(this.txtValorFinalMenuVenda);
            this.groupBox5.Controls.Add(this.txtDescontoMenuVenda);
            this.groupBox5.Controls.Add(this.txtTaxasMenuVenda);
            this.groupBox5.Controls.Add(this.txtTotalMenuVenda);
            this.groupBox5.Location = new System.Drawing.Point(427, 500);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(395, 156);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Resumo";
            // 
            // lblValorFinalMenuVenda
            // 
            this.lblValorFinalMenuVenda.AutoSize = true;
            this.lblValorFinalMenuVenda.Location = new System.Drawing.Point(59, 127);
            this.lblValorFinalMenuVenda.Name = "lblValorFinalMenuVenda";
            this.lblValorFinalMenuVenda.Size = new System.Drawing.Size(59, 13);
            this.lblValorFinalMenuVenda.TabIndex = 7;
            this.lblValorFinalMenuVenda.Text = "Valor Final:";
            // 
            // lblDescontoMenuVenda
            // 
            this.lblDescontoMenuVenda.AutoSize = true;
            this.lblDescontoMenuVenda.Location = new System.Drawing.Point(59, 96);
            this.lblDescontoMenuVenda.Name = "lblDescontoMenuVenda";
            this.lblDescontoMenuVenda.Size = new System.Drawing.Size(56, 13);
            this.lblDescontoMenuVenda.TabIndex = 6;
            this.lblDescontoMenuVenda.Text = "Desconto:";
            // 
            // lblTaxasMenuVenda
            // 
            this.lblTaxasMenuVenda.AutoSize = true;
            this.lblTaxasMenuVenda.Location = new System.Drawing.Point(59, 65);
            this.lblTaxasMenuVenda.Name = "lblTaxasMenuVenda";
            this.lblTaxasMenuVenda.Size = new System.Drawing.Size(39, 13);
            this.lblTaxasMenuVenda.TabIndex = 5;
            this.lblTaxasMenuVenda.Text = "Taxas:";
            // 
            // lblTotalMenuVenda
            // 
            this.lblTotalMenuVenda.AutoSize = true;
            this.lblTotalMenuVenda.Location = new System.Drawing.Point(59, 32);
            this.lblTotalMenuVenda.Name = "lblTotalMenuVenda";
            this.lblTotalMenuVenda.Size = new System.Drawing.Size(34, 13);
            this.lblTotalMenuVenda.TabIndex = 4;
            this.lblTotalMenuVenda.Text = "Total:";
            // 
            // txtValorFinalMenuVenda
            // 
            this.txtValorFinalMenuVenda.Location = new System.Drawing.Point(150, 124);
            this.txtValorFinalMenuVenda.Name = "txtValorFinalMenuVenda";
            this.txtValorFinalMenuVenda.Size = new System.Drawing.Size(194, 20);
            this.txtValorFinalMenuVenda.TabIndex = 3;
            // 
            // txtDescontoMenuVenda
            // 
            this.txtDescontoMenuVenda.Location = new System.Drawing.Point(150, 93);
            this.txtDescontoMenuVenda.Name = "txtDescontoMenuVenda";
            this.txtDescontoMenuVenda.Size = new System.Drawing.Size(194, 20);
            this.txtDescontoMenuVenda.TabIndex = 2;
            // 
            // txtTaxasMenuVenda
            // 
            this.txtTaxasMenuVenda.Location = new System.Drawing.Point(150, 62);
            this.txtTaxasMenuVenda.Name = "txtTaxasMenuVenda";
            this.txtTaxasMenuVenda.Size = new System.Drawing.Size(194, 20);
            this.txtTaxasMenuVenda.TabIndex = 1;
            // 
            // txtTotalMenuVenda
            // 
            this.txtTotalMenuVenda.Location = new System.Drawing.Point(150, 29);
            this.txtTotalMenuVenda.Multiline = true;
            this.txtTotalMenuVenda.Name = "txtTotalMenuVenda";
            this.txtTotalMenuVenda.Size = new System.Drawing.Size(194, 20);
            this.txtTotalMenuVenda.TabIndex = 0;
            // 
            // MenuVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(834, 668);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MenuVendas";
            this.Text = "Venda";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtClienteMenuVenda;
        private System.Windows.Forms.TextBox txtDataMenuVenda;
        private System.Windows.Forms.TextBox txtNMenuVenda;
        private System.Windows.Forms.Label lblClienteMenuVenda;
        private System.Windows.Forms.Label lblDataMenuVenda;
        private System.Windows.Forms.Label lblNMenuVenda;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSubTotalMenuVenda;
        private System.Windows.Forms.Label lblSubTotalMenuVenda;
        private System.Windows.Forms.TextBox txtQuantidadeMenuVenda;
        private System.Windows.Forms.Label lblQuantidadeMenuVenda;
        private System.Windows.Forms.TextBox txtPrecoMenuVenda;
        private System.Windows.Forms.TextBox txtDescricaoMenuVenda;
        private System.Windows.Forms.TextBox txtCodigoMenuVenda;
        private System.Windows.Forms.Label lblPrecoMenuVenda;
        private System.Windows.Forms.Label lblDescricaoMenuVenda;
        private System.Windows.Forms.Label lblCodigoMenuVenda;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblValorFinalMenuVenda;
        private System.Windows.Forms.Label lblDescontoMenuVenda;
        private System.Windows.Forms.Label lblTaxasMenuVenda;
        private System.Windows.Forms.Label lblTotalMenuVenda;
        private System.Windows.Forms.TextBox txtValorFinalMenuVenda;
        private System.Windows.Forms.TextBox txtDescontoMenuVenda;
        private System.Windows.Forms.TextBox txtTaxasMenuVenda;
        private System.Windows.Forms.TextBox txtTotalMenuVenda;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label16;
    }
}