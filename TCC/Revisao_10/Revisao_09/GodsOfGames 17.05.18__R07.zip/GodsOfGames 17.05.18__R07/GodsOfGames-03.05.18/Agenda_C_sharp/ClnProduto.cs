﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda_C_sharp
{
    class ClnProduto
    {
        private string comando;

        //Cria objeto para acesso a Camada de Dados
        cldBancoDados objBancoDados = new cldBancoDados();

        public DataTable PesquisarPorTipo(string strDescricao)
        {
            return null;
        }

        public DataTable LocalizarPorNome(string strDescricao)
        {
            comando = "Select tipo, nome, genero, faixa_Etaria from tb_Produto where tipo like '%" +
            strDescricao + "%' and Ativo='1' order by cd_produto";

            //comando = "Select*from T_DadosAgenda";

            //Envia a consulta por parâmetro para objeto e aguarda o retorno
            return objBancoDados.RetornaTabela(comando);

            ////Comando SQL PARA iNSERIR
            //public void Gravar()
            //{
            //    comando = "INSERT INTO tb_produto";
            //    comando += ("values(");
            //    comando += ("'" + NomeCadastroDeProduto + "',");
            //    comando += ("'" + TipoCadastroDeProduto + "',");
            //    comando += ("'" + FornecedorCadastroDeProduto + "',");
            //    comando += ("'" + FabricanteCadastroDeProduto + "',");
            //    comando += ("'" + GeneroCadastroDeProduto + "',");
            //    comando += ("'" + PlataformaCadastroDeProduto + "',");
            //    comando += ("'" + PrecoCadastroDeProduto + "',");
            //    comando += ("'" + QuantidadeCadastroDeProduto + "',");
            //    comando += ("'1'");
            //    comando += (")");
            //    objBancoDados.ExecutaComando(comando);
            //}
            ////Comando SQL PARA ALTERAR
            //public void Alterar()
            //{
            //    comando = "UPDATE tb_produto";
            //    comando += ("values(");
            //    comando += ("'" + NomeCadastroDeProduto + "',");
            //    comando += ("'" + TipoCadastroDeProduto + "',");
            //    comando += ("'" + FornecedorCadastroDeProduto + "',");
            //    comando += ("'" + FabricanteCadastroDeProduto + "',");
            //    comando += ("'" + GeneroCadastroDeProduto + "',");
            //    comando += ("'" + PlataformaCadastroDeProduto + "',");
            //    comando += ("'" + PrecoCadastroDeProduto + "',");
            //    comando += ("'" + QuantidadeCadastroDeProduto + "',");
            //    comando += ("'1'");
            //    comando += (")");
            //    objBancoDados.ExecutaComando(comando);
            //}





        }
    }
}
