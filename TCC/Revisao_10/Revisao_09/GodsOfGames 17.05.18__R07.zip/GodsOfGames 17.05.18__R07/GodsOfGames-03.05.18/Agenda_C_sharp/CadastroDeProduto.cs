﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_C_sharp
{
    public partial class CadastroDeProduto : Form
    {
        public CadastroDeProduto()
        {
            InitializeComponent();
        }

        private void CadastroDeProduto_Load(object sender, EventArgs e)
        {

        }

        private void btnGravarCadastroDeProduto_Click(object sender, EventArgs e)
        {
            //valida campos em branco
            if ((txtTipoCadastrodeProduto.Text == "") || (txtNomeCadastroDeProduto.Text == "") ||
                (txtGeneroCadastrodeProduto.Text == "") || (txtFabricanteCadastrodeProduto.Text == "") ||
                (txtPlataformaCadastrodeProduto.Text == "") || (txtPrecoCadastrodeProduto.Text == "") ||
                (txtQuantidadeCadastrodeProduto.Text == "") || (txtFornecedorCadastrodeProduto.Text == ""))
            {
                MessageBox.Show("Os campos com * são Obrigatórios", "item Novo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNomeCadastroDeProduto.Focus();
            }
            else
            {
                ClnProduto objClnProduto = new ClnProduto();

                //objClnProduto.Tipo = txtTipoCadastrodeProduto.Text;
                //objClnProduto.Nome = txtNomeCadastroDeProduto.Text;
                //objClnProduto.Genero = txtGeneroCadastrodeProduto.Text;
                //objClnProduto.Fabricante = txtFabricanteCadastrodeProduto.Text;
                //objClnProduto.Plataforma = txtPlataformaCadastrodeProduto.Text;
                //objClnProduto.Preco = txtPrecoCadastrodeProduto.Text;
                //objClnProduto.Fornecedor = txtFornecedorCadastrodeProduto.Text;
                //if (txtCod.Text == "")
                //{
                //    objClnProduto.Gravar();
                //    MessageBox.Show("Registro Gravado com sucesso", "Item Novo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //}
                //else if (txtCod.Text !== "")
                //{
                //    objClnProduto.Cod = txtCod.Text;
                //    objClnProduto.Alterar();
                //    MessageBox.Show("Registro Número" + txtCod.Text + "Alterado com sucesso", "Alteração", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //}
                //Close();



            }

        }
    }
}
