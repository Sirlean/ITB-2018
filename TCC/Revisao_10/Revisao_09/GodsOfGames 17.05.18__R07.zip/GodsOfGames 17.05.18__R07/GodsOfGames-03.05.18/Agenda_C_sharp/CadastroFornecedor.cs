﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_C_sharp
{
    public partial class CadastroFornecedor : Form
    {
        public CadastroFornecedor()
        {
            InitializeComponent();
        }

        private void txtMaskCepCadastroCliente_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnGravarCadastroFornecedor_Click(object sender, EventArgs e)
        {

        }

        private void btnSairCadastroFornecedor_Click(object sender, EventArgs e)
        {

        }
    }
}
