﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data; //para uso do DataTable (tabela de Dados)
using System.Data.SqlClient; // Para uso do DataReader (Dados para Leitura)

namespace Agenda_C_sharp
{
    class ClnUtil
    {
        string comando = "";

        cldBancoDados objBancoDados = new cldBancoDados();
        public DataTable PreencherUF()
        {
            comando = "select UF from T_UF";
            return objBancoDados.RetornaTabela(comando);

        }
        public SqlDataReader ProcurarCep(string cep)
        {
            comando = "select * from CepFiltradas$ where Cep='" + cep + "'";
            return objBancoDados.RetornaLinha(comando);
        }
    }
}

