﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda_C_sharp
{
    class ClnFornecedor
    {
        private int _cd_Fornecedor;
        private string _ds_Fornecedor, _Cnpj, _NomeFantasia, _RazaoSocial, _Telefone, _Celular, _Email, _Cep, _Endereco, _EndNumero, _EndComplemento, _Bairro, _Cidade, _UF;
        private string comando;

        public int Cd_Fornecedor { get => _cd_Fornecedor; set => _cd_Fornecedor = value; }
        public string Ds_Fornecedor { get => _ds_Fornecedor; set => _ds_Fornecedor = value; }
        public string Cnpj { get => _Cnpj; set => _Cnpj = value; }
        public string NomeFantasia { get => _NomeFantasia; set => _NomeFantasia = value; }
        public string RazaoSocial { get => _RazaoSocial; set => _RazaoSocial = value; }
        public string Telefone { get => _Telefone; set => _Telefone = value; }
        public string Celular { get => _Celular; set => _Celular = value; }
        public string Email { get => _Email; set => _Email = value; }
        public string Cep { get => _Cep; set => _Cep = value; }
        public string Endereco { get => _Endereco; set => _Endereco = value; }
        public string EndNumero { get => _EndNumero; set => _EndNumero = value; }
        public string EndComplemento { get => _EndComplemento; set => _EndComplemento = value; }
        public string Bairro { get => _Bairro; set => _Bairro = value; }
        public string Cidade { get => _Cidade; set => _Cidade = value; }
        public string UF { get => _UF; set => _UF = value; }


        public DataTable LocalizarPorCampo(string strValorCampo,string strNomeCampo)
        {
            cldBancoDados objBancoDados = new cldBancoDados();

            comando = "select cd_fornecedor, ds_Fornecedor, Cnpj, NomeFantasia, RazaoSocial, Telefone, Celular, Email from Tb_fornecedor where " + strNomeCampo+" like '%" +
            strValorCampo + "%' and Ativo= 1 order by cd_fornecedor";

            return objBancoDados.RetornaTabela(comando);
        }
    }

}
