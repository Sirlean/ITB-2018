﻿namespace Agenda_C_sharp
{
    partial class CadastroDeProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroDeProduto));
            this.lblTipo = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtFornecedorCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.btnGravarCadastroDeProduto = new System.Windows.Forms.Button();
            this.txtPlataformaCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.cboCondicaoCadastrodeProduto = new System.Windows.Forms.ComboBox();
            this.lblPlataformaCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblFornecedorCadastrodeProduto = new System.Windows.Forms.Label();
            this.txtFabricanteCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.cboFaixaEtariaCadastrodeProduto = new System.Windows.Forms.ComboBox();
            this.txtPrecoCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.lblCondicaoCadastrodeProduto = new System.Windows.Forms.Label();
            this.txtQuantidadeCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.txtGeneroCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.txtNomeCadastroDeProduto = new System.Windows.Forms.TextBox();
            this.txtTipoCadastrodeProduto = new System.Windows.Forms.TextBox();
            this.lblTipoCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblQuantidadeCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblNomeCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblFabricanteCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblGeneroCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblPrecoCadastrodeProduto = new System.Windows.Forms.Label();
            this.lblFaixaEtariaCadastrodeProduto = new System.Windows.Forms.Label();
            this.btnSairCadastroDeProduto = new System.Windows.Forms.Button();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.LblCod = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(12, 9);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(0, 16);
            this.lblTipo.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtFornecedorCadastrodeProduto);
            this.groupBox1.Controls.Add(this.btnGravarCadastroDeProduto);
            this.groupBox1.Controls.Add(this.txtPlataformaCadastrodeProduto);
            this.groupBox1.Controls.Add(this.cboCondicaoCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblPlataformaCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblFornecedorCadastrodeProduto);
            this.groupBox1.Controls.Add(this.txtFabricanteCadastrodeProduto);
            this.groupBox1.Controls.Add(this.cboFaixaEtariaCadastrodeProduto);
            this.groupBox1.Controls.Add(this.txtPrecoCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblCondicaoCadastrodeProduto);
            this.groupBox1.Controls.Add(this.txtQuantidadeCadastrodeProduto);
            this.groupBox1.Controls.Add(this.txtGeneroCadastrodeProduto);
            this.groupBox1.Controls.Add(this.txtNomeCadastroDeProduto);
            this.groupBox1.Controls.Add(this.txtTipoCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblTipoCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblQuantidadeCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblNomeCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblFabricanteCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblGeneroCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblPrecoCadastrodeProduto);
            this.groupBox1.Controls.Add(this.lblFaixaEtariaCadastrodeProduto);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(27, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(697, 247);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro De Produto";
            // 
            // txtFornecedorCadastrodeProduto
            // 
            this.txtFornecedorCadastrodeProduto.Location = new System.Drawing.Point(407, 160);
            this.txtFornecedorCadastrodeProduto.Name = "txtFornecedorCadastrodeProduto";
            this.txtFornecedorCadastrodeProduto.Size = new System.Drawing.Size(175, 22);
            this.txtFornecedorCadastrodeProduto.TabIndex = 19;
            // 
            // btnGravarCadastroDeProduto
            // 
            this.btnGravarCadastroDeProduto.Location = new System.Drawing.Point(607, 205);
            this.btnGravarCadastroDeProduto.Name = "btnGravarCadastroDeProduto";
            this.btnGravarCadastroDeProduto.Size = new System.Drawing.Size(75, 23);
            this.btnGravarCadastroDeProduto.TabIndex = 13;
            this.btnGravarCadastroDeProduto.Text = "&Gravar";
            this.btnGravarCadastroDeProduto.UseVisualStyleBackColor = true;
            this.btnGravarCadastroDeProduto.Click += new System.EventHandler(this.btnGravarCadastroDeProduto_Click);
            // 
            // txtPlataformaCadastrodeProduto
            // 
            this.txtPlataformaCadastrodeProduto.Location = new System.Drawing.Point(194, 161);
            this.txtPlataformaCadastrodeProduto.Name = "txtPlataformaCadastrodeProduto";
            this.txtPlataformaCadastrodeProduto.Size = new System.Drawing.Size(107, 22);
            this.txtPlataformaCadastrodeProduto.TabIndex = 18;
            // 
            // cboCondicaoCadastrodeProduto
            // 
            this.cboCondicaoCadastrodeProduto.FormattingEnabled = true;
            this.cboCondicaoCadastrodeProduto.Items.AddRange(new object[] {
            "Novo",
            "Usado"});
            this.cboCondicaoCadastrodeProduto.Location = new System.Drawing.Point(429, 110);
            this.cboCondicaoCadastrodeProduto.Name = "cboCondicaoCadastrodeProduto";
            this.cboCondicaoCadastrodeProduto.Size = new System.Drawing.Size(116, 24);
            this.cboCondicaoCadastrodeProduto.TabIndex = 17;
            // 
            // lblPlataformaCadastrodeProduto
            // 
            this.lblPlataformaCadastrodeProduto.AutoSize = true;
            this.lblPlataformaCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlataformaCadastrodeProduto.Location = new System.Drawing.Point(95, 163);
            this.lblPlataformaCadastrodeProduto.Name = "lblPlataformaCadastrodeProduto";
            this.lblPlataformaCadastrodeProduto.Size = new System.Drawing.Size(82, 16);
            this.lblPlataformaCadastrodeProduto.TabIndex = 6;
            this.lblPlataformaCadastrodeProduto.Text = "Plataforma:";
            // 
            // lblFornecedorCadastrodeProduto
            // 
            this.lblFornecedorCadastrodeProduto.AutoSize = true;
            this.lblFornecedorCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFornecedorCadastrodeProduto.Location = new System.Drawing.Point(316, 162);
            this.lblFornecedorCadastrodeProduto.Name = "lblFornecedorCadastrodeProduto";
            this.lblFornecedorCadastrodeProduto.Size = new System.Drawing.Size(85, 16);
            this.lblFornecedorCadastrodeProduto.TabIndex = 10;
            this.lblFornecedorCadastrodeProduto.Text = "Fornecedor:";
            // 
            // txtFabricanteCadastrodeProduto
            // 
            this.txtFabricanteCadastrodeProduto.Location = new System.Drawing.Point(229, 109);
            this.txtFabricanteCadastrodeProduto.Name = "txtFabricanteCadastrodeProduto";
            this.txtFabricanteCadastrodeProduto.Size = new System.Drawing.Size(117, 22);
            this.txtFabricanteCadastrodeProduto.TabIndex = 16;
            // 
            // cboFaixaEtariaCadastrodeProduto
            // 
            this.cboFaixaEtariaCadastrodeProduto.FormattingEnabled = true;
            this.cboFaixaEtariaCadastrodeProduto.Location = new System.Drawing.Point(319, 66);
            this.cboFaixaEtariaCadastrodeProduto.Name = "cboFaixaEtariaCadastrodeProduto";
            this.cboFaixaEtariaCadastrodeProduto.Size = new System.Drawing.Size(116, 24);
            this.cboFaixaEtariaCadastrodeProduto.TabIndex = 15;
            // 
            // txtPrecoCadastrodeProduto
            // 
            this.txtPrecoCadastrodeProduto.Location = new System.Drawing.Point(65, 106);
            this.txtPrecoCadastrodeProduto.Name = "txtPrecoCadastrodeProduto";
            this.txtPrecoCadastrodeProduto.Size = new System.Drawing.Size(73, 22);
            this.txtPrecoCadastrodeProduto.TabIndex = 14;
            // 
            // lblCondicaoCadastrodeProduto
            // 
            this.lblCondicaoCadastrodeProduto.AutoSize = true;
            this.lblCondicaoCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCondicaoCadastrodeProduto.Location = new System.Drawing.Point(357, 113);
            this.lblCondicaoCadastrodeProduto.Name = "lblCondicaoCadastrodeProduto";
            this.lblCondicaoCadastrodeProduto.Size = new System.Drawing.Size(72, 16);
            this.lblCondicaoCadastrodeProduto.TabIndex = 5;
            this.lblCondicaoCadastrodeProduto.Text = "Condição:";
            // 
            // txtQuantidadeCadastrodeProduto
            // 
            this.txtQuantidadeCadastrodeProduto.Location = new System.Drawing.Point(539, 67);
            this.txtQuantidadeCadastrodeProduto.Name = "txtQuantidadeCadastrodeProduto";
            this.txtQuantidadeCadastrodeProduto.Size = new System.Drawing.Size(99, 22);
            this.txtQuantidadeCadastrodeProduto.TabIndex = 13;
            // 
            // txtGeneroCadastrodeProduto
            // 
            this.txtGeneroCadastrodeProduto.Location = new System.Drawing.Point(98, 67);
            this.txtGeneroCadastrodeProduto.Name = "txtGeneroCadastrodeProduto";
            this.txtGeneroCadastrodeProduto.Size = new System.Drawing.Size(117, 22);
            this.txtGeneroCadastrodeProduto.TabIndex = 12;
            // 
            // txtNomeCadastroDeProduto
            // 
            this.txtNomeCadastroDeProduto.Location = new System.Drawing.Point(194, 31);
            this.txtNomeCadastroDeProduto.Name = "txtNomeCadastroDeProduto";
            this.txtNomeCadastroDeProduto.Size = new System.Drawing.Size(467, 22);
            this.txtNomeCadastroDeProduto.TabIndex = 11;
            // 
            // txtTipoCadastrodeProduto
            // 
            this.txtTipoCadastrodeProduto.Location = new System.Drawing.Point(45, 29);
            this.txtTipoCadastrodeProduto.Name = "txtTipoCadastrodeProduto";
            this.txtTipoCadastrodeProduto.Size = new System.Drawing.Size(93, 22);
            this.txtTipoCadastrodeProduto.TabIndex = 10;
            // 
            // lblTipoCadastrodeProduto
            // 
            this.lblTipoCadastrodeProduto.AutoSize = true;
            this.lblTipoCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoCadastrodeProduto.Location = new System.Drawing.Point(6, 31);
            this.lblTipoCadastrodeProduto.Name = "lblTipoCadastrodeProduto";
            this.lblTipoCadastrodeProduto.Size = new System.Drawing.Size(40, 16);
            this.lblTipoCadastrodeProduto.TabIndex = 0;
            this.lblTipoCadastrodeProduto.Text = "Tipo:";
            // 
            // lblQuantidadeCadastrodeProduto
            // 
            this.lblQuantidadeCadastrodeProduto.AutoSize = true;
            this.lblQuantidadeCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidadeCadastrodeProduto.Location = new System.Drawing.Point(455, 69);
            this.lblQuantidadeCadastrodeProduto.Name = "lblQuantidadeCadastrodeProduto";
            this.lblQuantidadeCadastrodeProduto.Size = new System.Drawing.Size(86, 16);
            this.lblQuantidadeCadastrodeProduto.TabIndex = 7;
            this.lblQuantidadeCadastrodeProduto.Text = "Quantidade:";
            // 
            // lblNomeCadastrodeProduto
            // 
            this.lblNomeCadastrodeProduto.AutoSize = true;
            this.lblNomeCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCadastrodeProduto.Location = new System.Drawing.Point(146, 33);
            this.lblNomeCadastrodeProduto.Name = "lblNomeCadastrodeProduto";
            this.lblNomeCadastrodeProduto.Size = new System.Drawing.Size(49, 16);
            this.lblNomeCadastrodeProduto.TabIndex = 3;
            this.lblNomeCadastrodeProduto.Text = "Nome:";
            // 
            // lblFabricanteCadastrodeProduto
            // 
            this.lblFabricanteCadastrodeProduto.AutoSize = true;
            this.lblFabricanteCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFabricanteCadastrodeProduto.Location = new System.Drawing.Point(150, 110);
            this.lblFabricanteCadastrodeProduto.Name = "lblFabricanteCadastrodeProduto";
            this.lblFabricanteCadastrodeProduto.Size = new System.Drawing.Size(80, 16);
            this.lblFabricanteCadastrodeProduto.TabIndex = 8;
            this.lblFabricanteCadastrodeProduto.Text = "Fabricante:";
            // 
            // lblGeneroCadastrodeProduto
            // 
            this.lblGeneroCadastrodeProduto.AutoSize = true;
            this.lblGeneroCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneroCadastrodeProduto.Location = new System.Drawing.Point(38, 70);
            this.lblGeneroCadastrodeProduto.Name = "lblGeneroCadastrodeProduto";
            this.lblGeneroCadastrodeProduto.Size = new System.Drawing.Size(63, 16);
            this.lblGeneroCadastrodeProduto.TabIndex = 2;
            this.lblGeneroCadastrodeProduto.Text = "Genero :";
            // 
            // lblPrecoCadastrodeProduto
            // 
            this.lblPrecoCadastrodeProduto.AutoSize = true;
            this.lblPrecoCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoCadastrodeProduto.Location = new System.Drawing.Point(6, 107);
            this.lblPrecoCadastrodeProduto.Name = "lblPrecoCadastrodeProduto";
            this.lblPrecoCadastrodeProduto.Size = new System.Drawing.Size(53, 16);
            this.lblPrecoCadastrodeProduto.TabIndex = 9;
            this.lblPrecoCadastrodeProduto.Text = "Preço :";
            // 
            // lblFaixaEtariaCadastrodeProduto
            // 
            this.lblFaixaEtariaCadastrodeProduto.AutoSize = true;
            this.lblFaixaEtariaCadastrodeProduto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFaixaEtariaCadastrodeProduto.Location = new System.Drawing.Point(229, 68);
            this.lblFaixaEtariaCadastrodeProduto.Name = "lblFaixaEtariaCadastrodeProduto";
            this.lblFaixaEtariaCadastrodeProduto.Size = new System.Drawing.Size(92, 16);
            this.lblFaixaEtariaCadastrodeProduto.TabIndex = 4;
            this.lblFaixaEtariaCadastrodeProduto.Text = "Faixa_Etaria:";
            // 
            // btnSairCadastroDeProduto
            // 
            this.btnSairCadastroDeProduto.Location = new System.Drawing.Point(634, 316);
            this.btnSairCadastroDeProduto.Name = "btnSairCadastroDeProduto";
            this.btnSairCadastroDeProduto.Size = new System.Drawing.Size(77, 23);
            this.btnSairCadastroDeProduto.TabIndex = 14;
            this.btnSairCadastroDeProduto.Text = "Sair";
            this.btnSairCadastroDeProduto.UseVisualStyleBackColor = true;
            // 
            // txtCod
            // 
            this.txtCod.Location = new System.Drawing.Point(92, 22);
            this.txtCod.Multiline = true;
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(83, 20);
            this.txtCod.TabIndex = 16;
            // 
            // LblCod
            // 
            this.LblCod.AutoSize = true;
            this.LblCod.BackColor = System.Drawing.SystemColors.Control;
            this.LblCod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCod.Location = new System.Drawing.Point(34, 24);
            this.LblCod.Name = "LblCod";
            this.LblCod.Size = new System.Drawing.Size(55, 16);
            this.LblCod.TabIndex = 15;
            this.LblCod.Text = "Código:";
            // 
            // CadastroDeProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 351);
            this.Controls.Add(this.txtCod);
            this.Controls.Add(this.LblCod);
            this.Controls.Add(this.btnSairCadastroDeProduto);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTipo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CadastroDeProduto";
            this.Text = "CadastroDeProduto";
            this.Load += new System.EventHandler(this.CadastroDeProduto_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtFornecedorCadastrodeProduto;
        private System.Windows.Forms.TextBox txtPlataformaCadastrodeProduto;
        private System.Windows.Forms.ComboBox cboCondicaoCadastrodeProduto;
        private System.Windows.Forms.Label lblPlataformaCadastrodeProduto;
        private System.Windows.Forms.Label lblFornecedorCadastrodeProduto;
        private System.Windows.Forms.TextBox txtFabricanteCadastrodeProduto;
        private System.Windows.Forms.ComboBox cboFaixaEtariaCadastrodeProduto;
        private System.Windows.Forms.TextBox txtPrecoCadastrodeProduto;
        private System.Windows.Forms.Label lblCondicaoCadastrodeProduto;
        private System.Windows.Forms.TextBox txtQuantidadeCadastrodeProduto;
        private System.Windows.Forms.TextBox txtGeneroCadastrodeProduto;
        private System.Windows.Forms.TextBox txtTipoCadastrodeProduto;
        private System.Windows.Forms.Label lblTipoCadastrodeProduto;
        private System.Windows.Forms.Label lblQuantidadeCadastrodeProduto;
        private System.Windows.Forms.Label lblNomeCadastrodeProduto;
        private System.Windows.Forms.Label lblFabricanteCadastrodeProduto;
        private System.Windows.Forms.Label lblGeneroCadastrodeProduto;
        private System.Windows.Forms.Label lblPrecoCadastrodeProduto;
        private System.Windows.Forms.Label lblFaixaEtariaCadastrodeProduto;
        private System.Windows.Forms.Button btnSairCadastroDeProduto;
        public System.Windows.Forms.Button btnGravarCadastroDeProduto;
        public System.Windows.Forms.TextBox txtNomeCadastroDeProduto;
        public System.Windows.Forms.TextBox txtCod;
        public System.Windows.Forms.Label LblCod;
    }
}