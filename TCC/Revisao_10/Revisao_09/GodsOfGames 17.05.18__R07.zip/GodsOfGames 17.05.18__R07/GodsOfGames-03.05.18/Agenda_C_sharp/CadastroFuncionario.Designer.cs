﻿namespace Agenda_C_sharp
{
    partial class CadastroFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroFuncionario));
            this.btnSairCadastroFuncionario = new System.Windows.Forms.Button();
            this.btnGravarCadastroFuncionario = new System.Windows.Forms.Button();
            this.rbCadastroFuncionario = new System.Windows.Forms.RadioButton();
            this.rbMasculinoCadastroFuncionario = new System.Windows.Forms.RadioButton();
            this.lblGeneroCadastroCliente = new System.Windows.Forms.Label();
            this.txtCelularCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblCelularCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtRGCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblRGCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtEmailCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblEmailCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtCPFCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblCPFCadastroFuncionario = new System.Windows.Forms.Label();
            this.cboUFCadastroFuncionario = new System.Windows.Forms.ComboBox();
            this.txtNumeroCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.LblCod = new System.Windows.Forms.Label();
            this.lblNumeroCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtMaskCepCadastroFuncionario = new System.Windows.Forms.MaskedTextBox();
            this.txtCidadeCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.LblCidadeCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtBairroCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.txtEnderecoCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.LblBairroCadastroFuncionario = new System.Windows.Forms.Label();
            this.lblUfCadastroFuncionario = new System.Windows.Forms.Label();
            this.lblEnderecoCadastroFuncionario = new System.Windows.Forms.Label();
            this.lblCepCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtTelefoneCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblTelefoneCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtNomeCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblNomeCadastroFuncionario = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDataDmCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.txtDataAdmCadastroFuncionario = new System.Windows.Forms.TextBox();
            this.lblDataDmCadastroFuncionario = new System.Windows.Forms.Label();
            this.lblDataAdmCadastroFuncionario = new System.Windows.Forms.Label();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSairCadastroFuncionario
            // 
            this.btnSairCadastroFuncionario.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairCadastroFuncionario.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnSairCadastroFuncionario.Location = new System.Drawing.Point(700, 464);
            this.btnSairCadastroFuncionario.Name = "btnSairCadastroFuncionario";
            this.btnSairCadastroFuncionario.Size = new System.Drawing.Size(75, 23);
            this.btnSairCadastroFuncionario.TabIndex = 21;
            this.btnSairCadastroFuncionario.Text = "Sair";
            this.btnSairCadastroFuncionario.UseVisualStyleBackColor = true;
            // 
            // btnGravarCadastroFuncionario
            // 
            this.btnGravarCadastroFuncionario.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGravarCadastroFuncionario.Location = new System.Drawing.Point(593, 464);
            this.btnGravarCadastroFuncionario.Name = "btnGravarCadastroFuncionario";
            this.btnGravarCadastroFuncionario.Size = new System.Drawing.Size(75, 23);
            this.btnGravarCadastroFuncionario.TabIndex = 20;
            this.btnGravarCadastroFuncionario.Text = "Gravar";
            this.btnGravarCadastroFuncionario.UseVisualStyleBackColor = true;
            // 
            // rbCadastroFuncionario
            // 
            this.rbCadastroFuncionario.AutoSize = true;
            this.rbCadastroFuncionario.Location = new System.Drawing.Point(629, 77);
            this.rbCadastroFuncionario.Name = "rbCadastroFuncionario";
            this.rbCadastroFuncionario.Size = new System.Drawing.Size(89, 20);
            this.rbCadastroFuncionario.TabIndex = 29;
            this.rbCadastroFuncionario.TabStop = true;
            this.rbCadastroFuncionario.Text = "Feminino";
            this.rbCadastroFuncionario.UseVisualStyleBackColor = true;
            // 
            // rbMasculinoCadastroFuncionario
            // 
            this.rbMasculinoCadastroFuncionario.AutoSize = true;
            this.rbMasculinoCadastroFuncionario.Location = new System.Drawing.Point(516, 75);
            this.rbMasculinoCadastroFuncionario.Name = "rbMasculinoCadastroFuncionario";
            this.rbMasculinoCadastroFuncionario.Size = new System.Drawing.Size(96, 20);
            this.rbMasculinoCadastroFuncionario.TabIndex = 28;
            this.rbMasculinoCadastroFuncionario.TabStop = true;
            this.rbMasculinoCadastroFuncionario.Text = "Masculino";
            this.rbMasculinoCadastroFuncionario.UseVisualStyleBackColor = true;
            // 
            // lblGeneroCadastroCliente
            // 
            this.lblGeneroCadastroCliente.AutoSize = true;
            this.lblGeneroCadastroCliente.BackColor = System.Drawing.SystemColors.Control;
            this.lblGeneroCadastroCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneroCadastroCliente.Location = new System.Drawing.Point(581, 47);
            this.lblGeneroCadastroCliente.Name = "lblGeneroCadastroCliente";
            this.lblGeneroCadastroCliente.Size = new System.Drawing.Size(63, 16);
            this.lblGeneroCadastroCliente.TabIndex = 27;
            this.lblGeneroCadastroCliente.Text = "Genero:";
            // 
            // txtCelularCadastroFuncionario
            // 
            this.txtCelularCadastroFuncionario.Location = new System.Drawing.Point(329, 113);
            this.txtCelularCadastroFuncionario.Multiline = true;
            this.txtCelularCadastroFuncionario.Name = "txtCelularCadastroFuncionario";
            this.txtCelularCadastroFuncionario.Size = new System.Drawing.Size(149, 20);
            this.txtCelularCadastroFuncionario.TabIndex = 25;
            // 
            // lblCelularCadastroFuncionario
            // 
            this.lblCelularCadastroFuncionario.AutoSize = true;
            this.lblCelularCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblCelularCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCelularCadastroFuncionario.Location = new System.Drawing.Point(265, 115);
            this.lblCelularCadastroFuncionario.Name = "lblCelularCadastroFuncionario";
            this.lblCelularCadastroFuncionario.Size = new System.Drawing.Size(61, 16);
            this.lblCelularCadastroFuncionario.TabIndex = 24;
            this.lblCelularCadastroFuncionario.Text = "Celular:";
            // 
            // txtRGCadastroFuncionario
            // 
            this.txtRGCadastroFuncionario.Location = new System.Drawing.Point(326, 30);
            this.txtRGCadastroFuncionario.Multiline = true;
            this.txtRGCadastroFuncionario.Name = "txtRGCadastroFuncionario";
            this.txtRGCadastroFuncionario.Size = new System.Drawing.Size(201, 20);
            this.txtRGCadastroFuncionario.TabIndex = 23;
            // 
            // lblRGCadastroFuncionario
            // 
            this.lblRGCadastroFuncionario.AutoSize = true;
            this.lblRGCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblRGCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRGCadastroFuncionario.Location = new System.Drawing.Point(292, 32);
            this.lblRGCadastroFuncionario.Name = "lblRGCadastroFuncionario";
            this.lblRGCadastroFuncionario.Size = new System.Drawing.Size(34, 16);
            this.lblRGCadastroFuncionario.TabIndex = 22;
            this.lblRGCadastroFuncionario.Text = "RG:";
            // 
            // txtEmailCadastroFuncionario
            // 
            this.txtEmailCadastroFuncionario.Location = new System.Drawing.Point(67, 153);
            this.txtEmailCadastroFuncionario.Multiline = true;
            this.txtEmailCadastroFuncionario.Name = "txtEmailCadastroFuncionario";
            this.txtEmailCadastroFuncionario.Size = new System.Drawing.Size(301, 20);
            this.txtEmailCadastroFuncionario.TabIndex = 21;
            // 
            // lblEmailCadastroFuncionario
            // 
            this.lblEmailCadastroFuncionario.AutoSize = true;
            this.lblEmailCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblEmailCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailCadastroFuncionario.Location = new System.Drawing.Point(14, 155);
            this.lblEmailCadastroFuncionario.Name = "lblEmailCadastroFuncionario";
            this.lblEmailCadastroFuncionario.Size = new System.Drawing.Size(51, 16);
            this.lblEmailCadastroFuncionario.TabIndex = 20;
            this.lblEmailCadastroFuncionario.Text = "Email:";
            // 
            // txtCPFCadastroFuncionario
            // 
            this.txtCPFCadastroFuncionario.Location = new System.Drawing.Point(62, 29);
            this.txtCPFCadastroFuncionario.Multiline = true;
            this.txtCPFCadastroFuncionario.Name = "txtCPFCadastroFuncionario";
            this.txtCPFCadastroFuncionario.Size = new System.Drawing.Size(201, 20);
            this.txtCPFCadastroFuncionario.TabIndex = 19;
            // 
            // lblCPFCadastroFuncionario
            // 
            this.lblCPFCadastroFuncionario.AutoSize = true;
            this.lblCPFCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblCPFCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPFCadastroFuncionario.Location = new System.Drawing.Point(14, 31);
            this.lblCPFCadastroFuncionario.Name = "lblCPFCadastroFuncionario";
            this.lblCPFCadastroFuncionario.Size = new System.Drawing.Size(47, 16);
            this.lblCPFCadastroFuncionario.TabIndex = 18;
            this.lblCPFCadastroFuncionario.Text = "*CPF:";
            // 
            // cboUFCadastroFuncionario
            // 
            this.cboUFCadastroFuncionario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboUFCadastroFuncionario.FormattingEnabled = true;
            this.cboUFCadastroFuncionario.Location = new System.Drawing.Point(795, 239);
            this.cboUFCadastroFuncionario.Name = "cboUFCadastroFuncionario";
            this.cboUFCadastroFuncionario.Size = new System.Drawing.Size(53, 24);
            this.cboUFCadastroFuncionario.TabIndex = 17;
            // 
            // txtNumeroCadastroFuncionario
            // 
            this.txtNumeroCadastroFuncionario.Location = new System.Drawing.Point(584, 195);
            this.txtNumeroCadastroFuncionario.Multiline = true;
            this.txtNumeroCadastroFuncionario.Name = "txtNumeroCadastroFuncionario";
            this.txtNumeroCadastroFuncionario.Size = new System.Drawing.Size(46, 20);
            this.txtNumeroCadastroFuncionario.TabIndex = 17;
            // 
            // LblCod
            // 
            this.LblCod.AutoSize = true;
            this.LblCod.BackColor = System.Drawing.SystemColors.Control;
            this.LblCod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCod.Location = new System.Drawing.Point(24, 18);
            this.LblCod.Name = "LblCod";
            this.LblCod.Size = new System.Drawing.Size(55, 16);
            this.LblCod.TabIndex = 17;
            this.LblCod.Text = "Código:";
            // 
            // lblNumeroCadastroFuncionario
            // 
            this.lblNumeroCadastroFuncionario.AutoSize = true;
            this.lblNumeroCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblNumeroCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroCadastroFuncionario.Location = new System.Drawing.Point(547, 196);
            this.lblNumeroCadastroFuncionario.Name = "lblNumeroCadastroFuncionario";
            this.lblNumeroCadastroFuncionario.Size = new System.Drawing.Size(35, 16);
            this.lblNumeroCadastroFuncionario.TabIndex = 16;
            this.lblNumeroCadastroFuncionario.Text = "*Nº:";
            // 
            // txtMaskCepCadastroFuncionario
            // 
            this.txtMaskCepCadastroFuncionario.Location = new System.Drawing.Point(67, 192);
            this.txtMaskCepCadastroFuncionario.Mask = "00000-999";
            this.txtMaskCepCadastroFuncionario.Name = "txtMaskCepCadastroFuncionario";
            this.txtMaskCepCadastroFuncionario.Size = new System.Drawing.Size(83, 22);
            this.txtMaskCepCadastroFuncionario.TabIndex = 15;
            // 
            // txtCidadeCadastroFuncionario
            // 
            this.txtCidadeCadastroFuncionario.Location = new System.Drawing.Point(507, 239);
            this.txtCidadeCadastroFuncionario.Multiline = true;
            this.txtCidadeCadastroFuncionario.Name = "txtCidadeCadastroFuncionario";
            this.txtCidadeCadastroFuncionario.Size = new System.Drawing.Size(197, 20);
            this.txtCidadeCadastroFuncionario.TabIndex = 13;
            // 
            // LblCidadeCadastroFuncionario
            // 
            this.LblCidadeCadastroFuncionario.AutoSize = true;
            this.LblCidadeCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.LblCidadeCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCidadeCadastroFuncionario.Location = new System.Drawing.Point(438, 239);
            this.LblCidadeCadastroFuncionario.Name = "LblCidadeCadastroFuncionario";
            this.LblCidadeCadastroFuncionario.Size = new System.Drawing.Size(68, 16);
            this.LblCidadeCadastroFuncionario.TabIndex = 12;
            this.LblCidadeCadastroFuncionario.Text = "*Cidade:";
            // 
            // txtBairroCadastroFuncionario
            // 
            this.txtBairroCadastroFuncionario.Location = new System.Drawing.Point(86, 235);
            this.txtBairroCadastroFuncionario.Multiline = true;
            this.txtBairroCadastroFuncionario.Name = "txtBairroCadastroFuncionario";
            this.txtBairroCadastroFuncionario.Size = new System.Drawing.Size(346, 20);
            this.txtBairroCadastroFuncionario.TabIndex = 11;
            // 
            // txtEnderecoCadastroFuncionario
            // 
            this.txtEnderecoCadastroFuncionario.Location = new System.Drawing.Point(243, 193);
            this.txtEnderecoCadastroFuncionario.Multiline = true;
            this.txtEnderecoCadastroFuncionario.Name = "txtEnderecoCadastroFuncionario";
            this.txtEnderecoCadastroFuncionario.Size = new System.Drawing.Size(294, 20);
            this.txtEnderecoCadastroFuncionario.TabIndex = 2;
            // 
            // LblBairroCadastroFuncionario
            // 
            this.LblBairroCadastroFuncionario.AutoSize = true;
            this.LblBairroCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.LblBairroCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBairroCadastroFuncionario.Location = new System.Drawing.Point(14, 239);
            this.LblBairroCadastroFuncionario.Name = "LblBairroCadastroFuncionario";
            this.LblBairroCadastroFuncionario.Size = new System.Drawing.Size(60, 16);
            this.LblBairroCadastroFuncionario.TabIndex = 9;
            this.LblBairroCadastroFuncionario.Text = "*Bairro:";
            // 
            // lblUfCadastroFuncionario
            // 
            this.lblUfCadastroFuncionario.AutoSize = true;
            this.lblUfCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblUfCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUfCadastroFuncionario.Location = new System.Drawing.Point(727, 242);
            this.lblUfCadastroFuncionario.Name = "lblUfCadastroFuncionario";
            this.lblUfCadastroFuncionario.Size = new System.Drawing.Size(38, 16);
            this.lblUfCadastroFuncionario.TabIndex = 8;
            this.lblUfCadastroFuncionario.Text = "*UF:";
            // 
            // lblEnderecoCadastroFuncionario
            // 
            this.lblEnderecoCadastroFuncionario.AutoSize = true;
            this.lblEnderecoCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblEnderecoCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnderecoCadastroFuncionario.Location = new System.Drawing.Point(156, 195);
            this.lblEnderecoCadastroFuncionario.Name = "lblEnderecoCadastroFuncionario";
            this.lblEnderecoCadastroFuncionario.Size = new System.Drawing.Size(85, 16);
            this.lblEnderecoCadastroFuncionario.TabIndex = 7;
            this.lblEnderecoCadastroFuncionario.Text = "*Endereço:";
            // 
            // lblCepCadastroFuncionario
            // 
            this.lblCepCadastroFuncionario.AutoSize = true;
            this.lblCepCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblCepCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCepCadastroFuncionario.Location = new System.Drawing.Point(17, 194);
            this.lblCepCadastroFuncionario.Name = "lblCepCadastroFuncionario";
            this.lblCepCadastroFuncionario.Size = new System.Drawing.Size(44, 16);
            this.lblCepCadastroFuncionario.TabIndex = 5;
            this.lblCepCadastroFuncionario.Text = "*cep:";
            // 
            // txtTelefoneCadastroFuncionario
            // 
            this.txtTelefoneCadastroFuncionario.Location = new System.Drawing.Point(82, 113);
            this.txtTelefoneCadastroFuncionario.Multiline = true;
            this.txtTelefoneCadastroFuncionario.Name = "txtTelefoneCadastroFuncionario";
            this.txtTelefoneCadastroFuncionario.Size = new System.Drawing.Size(149, 20);
            this.txtTelefoneCadastroFuncionario.TabIndex = 2;
            // 
            // lblTelefoneCadastroFuncionario
            // 
            this.lblTelefoneCadastroFuncionario.AutoSize = true;
            this.lblTelefoneCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblTelefoneCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefoneCadastroFuncionario.Location = new System.Drawing.Point(6, 115);
            this.lblTelefoneCadastroFuncionario.Name = "lblTelefoneCadastroFuncionario";
            this.lblTelefoneCadastroFuncionario.Size = new System.Drawing.Size(74, 16);
            this.lblTelefoneCadastroFuncionario.TabIndex = 3;
            this.lblTelefoneCadastroFuncionario.Text = "Telefone:";
            // 
            // txtNomeCadastroFornecedor
            // 
            this.txtNomeCadastroFuncionario.Location = new System.Drawing.Point(68, 73);
            this.txtNomeCadastroFuncionario.Multiline = true;
            this.txtNomeCadastroFuncionario.Name = "txtNomeCadastroFornecedor";
            this.txtNomeCadastroFuncionario.Size = new System.Drawing.Size(424, 20);
            this.txtNomeCadastroFuncionario.TabIndex = 2;
            // 
            // lblNomeCadastroFuncionario
            // 
            this.lblNomeCadastroFuncionario.AutoSize = true;
            this.lblNomeCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblNomeCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCadastroFuncionario.Location = new System.Drawing.Point(6, 75);
            this.lblNomeCadastroFuncionario.Name = "lblNomeCadastroFuncionario";
            this.lblNomeCadastroFuncionario.Size = new System.Drawing.Size(59, 16);
            this.lblNomeCadastroFuncionario.TabIndex = 1;
            this.lblNomeCadastroFuncionario.Text = "*Nome:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtDataDmCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtDataAdmCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblDataDmCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblDataAdmCadastroFuncionario);
            this.groupBox1.Controls.Add(this.rbCadastroFuncionario);
            this.groupBox1.Controls.Add(this.rbMasculinoCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblGeneroCadastroCliente);
            this.groupBox1.Controls.Add(this.txtCelularCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblCelularCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtRGCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblRGCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtEmailCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblEmailCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtCPFCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblCPFCadastroFuncionario);
            this.groupBox1.Controls.Add(this.cboUFCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtNumeroCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblNumeroCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtMaskCepCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtCidadeCadastroFuncionario);
            this.groupBox1.Controls.Add(this.LblCidadeCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtBairroCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtEnderecoCadastroFuncionario);
            this.groupBox1.Controls.Add(this.LblBairroCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblUfCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblEnderecoCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblCepCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtTelefoneCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblTelefoneCadastroFuncionario);
            this.groupBox1.Controls.Add(this.txtNomeCadastroFuncionario);
            this.groupBox1.Controls.Add(this.lblNomeCadastroFuncionario);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(27, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(951, 374);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro Funcionário";
            // 
            // txtDataDmCadastroFuncionario
            // 
            this.txtDataDmCadastroFuncionario.Location = new System.Drawing.Point(455, 292);
            this.txtDataDmCadastroFuncionario.Multiline = true;
            this.txtDataDmCadastroFuncionario.Name = "txtDataDmCadastroFuncionario";
            this.txtDataDmCadastroFuncionario.Size = new System.Drawing.Size(127, 20);
            this.txtDataDmCadastroFuncionario.TabIndex = 33;
            // 
            // txtDataAdmCadastroFuncionario
            // 
            this.txtDataAdmCadastroFuncionario.Location = new System.Drawing.Point(160, 293);
            this.txtDataAdmCadastroFuncionario.Multiline = true;
            this.txtDataAdmCadastroFuncionario.Name = "txtDataAdmCadastroFuncionario";
            this.txtDataAdmCadastroFuncionario.Size = new System.Drawing.Size(127, 20);
            this.txtDataAdmCadastroFuncionario.TabIndex = 32;
            // 
            // lblDataDmCadastroFuncionario
            // 
            this.lblDataDmCadastroFuncionario.AutoSize = true;
            this.lblDataDmCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblDataDmCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataDmCadastroFuncionario.Location = new System.Drawing.Point(323, 295);
            this.lblDataDmCadastroFuncionario.Name = "lblDataDmCadastroFuncionario";
            this.lblDataDmCadastroFuncionario.Size = new System.Drawing.Size(125, 16);
            this.lblDataDmCadastroFuncionario.TabIndex = 31;
            this.lblDataDmCadastroFuncionario.Text = "*Data Demissão:";
            // 
            // lblDataAdmCadastroFuncionario
            // 
            this.lblDataAdmCadastroFuncionario.AutoSize = true;
            this.lblDataAdmCadastroFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.lblDataAdmCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataAdmCadastroFuncionario.Location = new System.Drawing.Point(24, 296);
            this.lblDataAdmCadastroFuncionario.Name = "lblDataAdmCadastroFuncionario";
            this.lblDataAdmCadastroFuncionario.Size = new System.Drawing.Size(124, 16);
            this.lblDataAdmCadastroFuncionario.TabIndex = 30;
            this.lblDataAdmCadastroFuncionario.Text = "*Data Admissão:";
            // 
            // txtCod
            // 
            this.txtCod.Location = new System.Drawing.Point(89, 18);
            this.txtCod.Multiline = true;
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(72, 20);
            this.txtCod.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(641, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 16);
            this.label1.TabIndex = 34;
            this.label1.Text = "Complemento:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(762, 199);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(156, 20);
            this.textBox1.TabIndex = 35;
            // 
            // CadastroFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 501);
            this.Controls.Add(this.btnSairCadastroFuncionario);
            this.Controls.Add(this.btnGravarCadastroFuncionario);
            this.Controls.Add(this.LblCod);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtCod);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CadastroFuncionario";
            this.Text = "CadastroFuncionario";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnSairCadastroFuncionario;
        public System.Windows.Forms.Button btnGravarCadastroFuncionario;
        public System.Windows.Forms.RadioButton rbCadastroFuncionario;
        public System.Windows.Forms.RadioButton rbMasculinoCadastroFuncionario;
        public System.Windows.Forms.Label lblGeneroCadastroCliente;
        public System.Windows.Forms.TextBox txtCelularCadastroFuncionario;
        public System.Windows.Forms.Label lblCelularCadastroFuncionario;
        public System.Windows.Forms.TextBox txtRGCadastroFuncionario;
        public System.Windows.Forms.Label lblRGCadastroFuncionario;
        public System.Windows.Forms.TextBox txtEmailCadastroFuncionario;
        public System.Windows.Forms.Label lblEmailCadastroFuncionario;
        public System.Windows.Forms.TextBox txtCPFCadastroFuncionario;
        public System.Windows.Forms.Label lblCPFCadastroFuncionario;
        public System.Windows.Forms.ComboBox cboUFCadastroFuncionario;
        public System.Windows.Forms.TextBox txtNumeroCadastroFuncionario;
        public System.Windows.Forms.Label LblCod;
        public System.Windows.Forms.Label lblNumeroCadastroFuncionario;
        public System.Windows.Forms.MaskedTextBox txtMaskCepCadastroFuncionario;
        public System.Windows.Forms.TextBox txtCidadeCadastroFuncionario;
        public System.Windows.Forms.Label LblCidadeCadastroFuncionario;
        public System.Windows.Forms.TextBox txtBairroCadastroFuncionario;
        public System.Windows.Forms.TextBox txtEnderecoCadastroFuncionario;
        public System.Windows.Forms.Label LblBairroCadastroFuncionario;
        public System.Windows.Forms.Label lblUfCadastroFuncionario;
        public System.Windows.Forms.Label lblEnderecoCadastroFuncionario;
        public System.Windows.Forms.Label lblCepCadastroFuncionario;
        public System.Windows.Forms.TextBox txtTelefoneCadastroFuncionario;
        public System.Windows.Forms.Label lblTelefoneCadastroFuncionario;
        public System.Windows.Forms.TextBox txtNomeCadastroFuncionario;
        public System.Windows.Forms.Label lblNomeCadastroFuncionario;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txtCod;
        public System.Windows.Forms.TextBox txtDataDmCadastroFuncionario;
        public System.Windows.Forms.TextBox txtDataAdmCadastroFuncionario;
        public System.Windows.Forms.Label lblDataDmCadastroFuncionario;
        public System.Windows.Forms.Label lblDataAdmCadastroFuncionario;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Label label1;
    }
}