﻿namespace Agenda_C_sharp
{
    partial class CadastroFornecedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroFornecedor));
            this.txtCelularCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblCelularCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtRGCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblRGCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtEmailCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblEmailCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtCPFCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblCPFCadastroFornecedor = new System.Windows.Forms.Label();
            this.cboUFCadastroFornecedor = new System.Windows.Forms.ComboBox();
            this.txtNumeroCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.lblNumeroCadastroFornecedor = new System.Windows.Forms.Label();
            this.btnSairCadastroFornecedor = new System.Windows.Forms.Button();
            this.btnGravarCadastroFornecedor = new System.Windows.Forms.Button();
            this.LblCod = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtComplementoCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblComplementoCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtMaskCepCadastroFornecedor = new System.Windows.Forms.MaskedTextBox();
            this.txtCidadeCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.LblCidadeCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtBairroCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.txtEnderecoCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.LblBairroCadastroFornecedor = new System.Windows.Forms.Label();
            this.lblUfCadastroFornecedor = new System.Windows.Forms.Label();
            this.lblEnderecoCadastroFornecedor = new System.Windows.Forms.Label();
            this.lblCepCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtTelefoneCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblTelefoneCadastroFornecedor = new System.Windows.Forms.Label();
            this.txtNomeCadastroFornecedor = new System.Windows.Forms.TextBox();
            this.lblNomeCadastroFornecedor = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCelularCadastroFornecedor
            // 
            this.txtCelularCadastroFornecedor.Location = new System.Drawing.Point(329, 113);
            this.txtCelularCadastroFornecedor.Multiline = true;
            this.txtCelularCadastroFornecedor.Name = "txtCelularCadastroFornecedor";
            this.txtCelularCadastroFornecedor.Size = new System.Drawing.Size(149, 20);
            this.txtCelularCadastroFornecedor.TabIndex = 25;
            // 
            // lblCelularCadastroFornecedor
            // 
            this.lblCelularCadastroFornecedor.AutoSize = true;
            this.lblCelularCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblCelularCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCelularCadastroFornecedor.Location = new System.Drawing.Point(265, 115);
            this.lblCelularCadastroFornecedor.Name = "lblCelularCadastroFornecedor";
            this.lblCelularCadastroFornecedor.Size = new System.Drawing.Size(61, 16);
            this.lblCelularCadastroFornecedor.TabIndex = 24;
            this.lblCelularCadastroFornecedor.Text = "Celular:";
            // 
            // txtRGCadastroFornecedor
            // 
            this.txtRGCadastroFornecedor.Location = new System.Drawing.Point(418, 30);
            this.txtRGCadastroFornecedor.Multiline = true;
            this.txtRGCadastroFornecedor.Name = "txtRGCadastroFornecedor";
            this.txtRGCadastroFornecedor.Size = new System.Drawing.Size(450, 20);
            this.txtRGCadastroFornecedor.TabIndex = 23;
            // 
            // lblRGCadastroFornecedor
            // 
            this.lblRGCadastroFornecedor.AutoSize = true;
            this.lblRGCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblRGCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRGCadastroFornecedor.Location = new System.Drawing.Point(295, 32);
            this.lblRGCadastroFornecedor.Name = "lblRGCadastroFornecedor";
            this.lblRGCadastroFornecedor.Size = new System.Drawing.Size(117, 16);
            this.lblRGCadastroFornecedor.TabIndex = 22;
            this.lblRGCadastroFornecedor.Text = "Nome Fantasia:";
            // 
            // txtEmailCadastroFornecedor
            // 
            this.txtEmailCadastroFornecedor.Location = new System.Drawing.Point(67, 153);
            this.txtEmailCadastroFornecedor.Multiline = true;
            this.txtEmailCadastroFornecedor.Name = "txtEmailCadastroFornecedor";
            this.txtEmailCadastroFornecedor.Size = new System.Drawing.Size(411, 20);
            this.txtEmailCadastroFornecedor.TabIndex = 21;
            // 
            // lblEmailCadastroFornecedor
            // 
            this.lblEmailCadastroFornecedor.AutoSize = true;
            this.lblEmailCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblEmailCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailCadastroFornecedor.Location = new System.Drawing.Point(14, 155);
            this.lblEmailCadastroFornecedor.Name = "lblEmailCadastroFornecedor";
            this.lblEmailCadastroFornecedor.Size = new System.Drawing.Size(51, 16);
            this.lblEmailCadastroFornecedor.TabIndex = 20;
            this.lblEmailCadastroFornecedor.Text = "Email:";
            // 
            // txtCPFCadastroFornecedor
            // 
            this.txtCPFCadastroFornecedor.Location = new System.Drawing.Point(76, 29);
            this.txtCPFCadastroFornecedor.Multiline = true;
            this.txtCPFCadastroFornecedor.Name = "txtCPFCadastroFornecedor";
            this.txtCPFCadastroFornecedor.Size = new System.Drawing.Size(201, 20);
            this.txtCPFCadastroFornecedor.TabIndex = 19;
            // 
            // lblCPFCadastroFornecedor
            // 
            this.lblCPFCadastroFornecedor.AutoSize = true;
            this.lblCPFCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblCPFCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPFCadastroFornecedor.Location = new System.Drawing.Point(14, 31);
            this.lblCPFCadastroFornecedor.Name = "lblCPFCadastroFornecedor";
            this.lblCPFCadastroFornecedor.Size = new System.Drawing.Size(57, 16);
            this.lblCPFCadastroFornecedor.TabIndex = 18;
            this.lblCPFCadastroFornecedor.Text = "*CNPJ:";
            // 
            // cboUFCadastroFornecedor
            // 
            this.cboUFCadastroFornecedor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboUFCadastroFornecedor.FormattingEnabled = true;
            this.cboUFCadastroFornecedor.Location = new System.Drawing.Point(695, 232);
            this.cboUFCadastroFornecedor.Name = "cboUFCadastroFornecedor";
            this.cboUFCadastroFornecedor.Size = new System.Drawing.Size(53, 24);
            this.cboUFCadastroFornecedor.TabIndex = 17;
            // 
            // txtNumeroCadastroFornecedor
            // 
            this.txtNumeroCadastroFornecedor.Location = new System.Drawing.Point(584, 195);
            this.txtNumeroCadastroFornecedor.Multiline = true;
            this.txtNumeroCadastroFornecedor.Name = "txtNumeroCadastroFornecedor";
            this.txtNumeroCadastroFornecedor.Size = new System.Drawing.Size(46, 20);
            this.txtNumeroCadastroFornecedor.TabIndex = 17;
            // 
            // txtCod
            // 
            this.txtCod.Location = new System.Drawing.Point(86, 9);
            this.txtCod.Multiline = true;
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(72, 20);
            this.txtCod.TabIndex = 23;
            // 
            // lblNumeroCadastroFornecedor
            // 
            this.lblNumeroCadastroFornecedor.AutoSize = true;
            this.lblNumeroCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblNumeroCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroCadastroFornecedor.Location = new System.Drawing.Point(543, 196);
            this.lblNumeroCadastroFornecedor.Name = "lblNumeroCadastroFornecedor";
            this.lblNumeroCadastroFornecedor.Size = new System.Drawing.Size(35, 16);
            this.lblNumeroCadastroFornecedor.TabIndex = 16;
            this.lblNumeroCadastroFornecedor.Text = "*Nº:";
            // 
            // btnSairCadastroFornecedor
            // 
            this.btnSairCadastroFornecedor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairCadastroFornecedor.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnSairCadastroFornecedor.Location = new System.Drawing.Point(697, 455);
            this.btnSairCadastroFornecedor.Name = "btnSairCadastroFornecedor";
            this.btnSairCadastroFornecedor.Size = new System.Drawing.Size(75, 23);
            this.btnSairCadastroFornecedor.TabIndex = 26;
            this.btnSairCadastroFornecedor.Text = "Sair";
            this.btnSairCadastroFornecedor.UseVisualStyleBackColor = true;
            this.btnSairCadastroFornecedor.Click += new System.EventHandler(this.btnSairCadastroFornecedor_Click);
            // 
            // btnGravarCadastroFornecedor
            // 
            this.btnGravarCadastroFornecedor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGravarCadastroFornecedor.Location = new System.Drawing.Point(564, 454);
            this.btnGravarCadastroFornecedor.Name = "btnGravarCadastroFornecedor";
            this.btnGravarCadastroFornecedor.Size = new System.Drawing.Size(75, 23);
            this.btnGravarCadastroFornecedor.TabIndex = 25;
            this.btnGravarCadastroFornecedor.Text = "Gravar";
            this.btnGravarCadastroFornecedor.UseVisualStyleBackColor = true;
            this.btnGravarCadastroFornecedor.Click += new System.EventHandler(this.btnGravarCadastroFornecedor_Click);
            // 
            // LblCod
            // 
            this.LblCod.AutoSize = true;
            this.LblCod.BackColor = System.Drawing.SystemColors.Control;
            this.LblCod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCod.Location = new System.Drawing.Point(21, 9);
            this.LblCod.Name = "LblCod";
            this.LblCod.Size = new System.Drawing.Size(55, 16);
            this.LblCod.TabIndex = 22;
            this.LblCod.Text = "Código:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtComplementoCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblComplementoCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtCelularCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblCelularCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtRGCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblRGCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtEmailCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblEmailCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtCPFCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblCPFCadastroFornecedor);
            this.groupBox1.Controls.Add(this.cboUFCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtNumeroCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblNumeroCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtMaskCepCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtCidadeCadastroFornecedor);
            this.groupBox1.Controls.Add(this.LblCidadeCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtBairroCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtEnderecoCadastroFornecedor);
            this.groupBox1.Controls.Add(this.LblBairroCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblUfCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblEnderecoCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblCepCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtTelefoneCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblTelefoneCadastroFornecedor);
            this.groupBox1.Controls.Add(this.txtNomeCadastroFornecedor);
            this.groupBox1.Controls.Add(this.lblNomeCadastroFornecedor);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(24, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(939, 350);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro Fornecedor";
            // 
            // txtComplementoCadastroFornecedor
            // 
            this.txtComplementoCadastroFornecedor.Location = new System.Drawing.Point(749, 195);
            this.txtComplementoCadastroFornecedor.Multiline = true;
            this.txtComplementoCadastroFornecedor.Name = "txtComplementoCadastroFornecedor";
            this.txtComplementoCadastroFornecedor.Size = new System.Drawing.Size(175, 20);
            this.txtComplementoCadastroFornecedor.TabIndex = 29;
            // 
            // lblComplementoCadastroFornecedor
            // 
            this.lblComplementoCadastroFornecedor.AutoSize = true;
            this.lblComplementoCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblComplementoCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComplementoCadastroFornecedor.Location = new System.Drawing.Point(636, 198);
            this.lblComplementoCadastroFornecedor.Name = "lblComplementoCadastroFornecedor";
            this.lblComplementoCadastroFornecedor.Size = new System.Drawing.Size(107, 16);
            this.lblComplementoCadastroFornecedor.TabIndex = 28;
            this.lblComplementoCadastroFornecedor.Text = "Complemento:";
            // 
            // txtMaskCepCadastroFornecedor
            // 
            this.txtMaskCepCadastroFornecedor.Location = new System.Drawing.Point(67, 192);
            this.txtMaskCepCadastroFornecedor.Mask = "00000-999";
            this.txtMaskCepCadastroFornecedor.Name = "txtMaskCepCadastroFornecedor";
            this.txtMaskCepCadastroFornecedor.Size = new System.Drawing.Size(83, 22);
            this.txtMaskCepCadastroFornecedor.TabIndex = 15;
            this.txtMaskCepCadastroFornecedor.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtMaskCepCadastroCliente_MaskInputRejected);
            // 
            // txtCidadeCadastroFornecedor
            // 
            this.txtCidadeCadastroFornecedor.Location = new System.Drawing.Point(418, 235);
            this.txtCidadeCadastroFornecedor.Multiline = true;
            this.txtCidadeCadastroFornecedor.Name = "txtCidadeCadastroFornecedor";
            this.txtCidadeCadastroFornecedor.Size = new System.Drawing.Size(197, 20);
            this.txtCidadeCadastroFornecedor.TabIndex = 13;
            // 
            // LblCidadeCadastroFornecedor
            // 
            this.LblCidadeCadastroFornecedor.AutoSize = true;
            this.LblCidadeCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.LblCidadeCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCidadeCadastroFornecedor.Location = new System.Drawing.Point(344, 235);
            this.LblCidadeCadastroFornecedor.Name = "LblCidadeCadastroFornecedor";
            this.LblCidadeCadastroFornecedor.Size = new System.Drawing.Size(68, 16);
            this.LblCidadeCadastroFornecedor.TabIndex = 12;
            this.LblCidadeCadastroFornecedor.Text = "*Cidade:";
            // 
            // txtBairroCadastroFornecedor
            // 
            this.txtBairroCadastroFornecedor.Location = new System.Drawing.Point(86, 235);
            this.txtBairroCadastroFornecedor.Multiline = true;
            this.txtBairroCadastroFornecedor.Name = "txtBairroCadastroFornecedor";
            this.txtBairroCadastroFornecedor.Size = new System.Drawing.Size(240, 20);
            this.txtBairroCadastroFornecedor.TabIndex = 11;
            // 
            // txtEnderecoCadastroFornecedor
            // 
            this.txtEnderecoCadastroFornecedor.Location = new System.Drawing.Point(243, 193);
            this.txtEnderecoCadastroFornecedor.Multiline = true;
            this.txtEnderecoCadastroFornecedor.Name = "txtEnderecoCadastroFornecedor";
            this.txtEnderecoCadastroFornecedor.Size = new System.Drawing.Size(294, 20);
            this.txtEnderecoCadastroFornecedor.TabIndex = 2;
            // 
            // LblBairroCadastroFornecedor
            // 
            this.LblBairroCadastroFornecedor.AutoSize = true;
            this.LblBairroCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.LblBairroCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBairroCadastroFornecedor.Location = new System.Drawing.Point(14, 239);
            this.LblBairroCadastroFornecedor.Name = "LblBairroCadastroFornecedor";
            this.LblBairroCadastroFornecedor.Size = new System.Drawing.Size(60, 16);
            this.LblBairroCadastroFornecedor.TabIndex = 9;
            this.LblBairroCadastroFornecedor.Text = "*Bairro:";
            // 
            // lblUfCadastroFornecedor
            // 
            this.lblUfCadastroFornecedor.AutoSize = true;
            this.lblUfCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblUfCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUfCadastroFornecedor.Location = new System.Drawing.Point(636, 239);
            this.lblUfCadastroFornecedor.Name = "lblUfCadastroFornecedor";
            this.lblUfCadastroFornecedor.Size = new System.Drawing.Size(38, 16);
            this.lblUfCadastroFornecedor.TabIndex = 8;
            this.lblUfCadastroFornecedor.Text = "*UF:";
            // 
            // lblEnderecoCadastroFornecedor
            // 
            this.lblEnderecoCadastroFornecedor.AutoSize = true;
            this.lblEnderecoCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblEnderecoCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnderecoCadastroFornecedor.Location = new System.Drawing.Point(156, 195);
            this.lblEnderecoCadastroFornecedor.Name = "lblEnderecoCadastroFornecedor";
            this.lblEnderecoCadastroFornecedor.Size = new System.Drawing.Size(85, 16);
            this.lblEnderecoCadastroFornecedor.TabIndex = 7;
            this.lblEnderecoCadastroFornecedor.Text = "*Endereço:";
            // 
            // lblCepCadastroFornecedor
            // 
            this.lblCepCadastroFornecedor.AutoSize = true;
            this.lblCepCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblCepCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCepCadastroFornecedor.Location = new System.Drawing.Point(17, 194);
            this.lblCepCadastroFornecedor.Name = "lblCepCadastroFornecedor";
            this.lblCepCadastroFornecedor.Size = new System.Drawing.Size(44, 16);
            this.lblCepCadastroFornecedor.TabIndex = 5;
            this.lblCepCadastroFornecedor.Text = "*cep:";
            // 
            // txtTelefoneCadastroFornecedor
            // 
            this.txtTelefoneCadastroFornecedor.Location = new System.Drawing.Point(82, 113);
            this.txtTelefoneCadastroFornecedor.Multiline = true;
            this.txtTelefoneCadastroFornecedor.Name = "txtTelefoneCadastroFornecedor";
            this.txtTelefoneCadastroFornecedor.Size = new System.Drawing.Size(149, 20);
            this.txtTelefoneCadastroFornecedor.TabIndex = 2;
            // 
            // lblTelefoneCadastroFornecedor
            // 
            this.lblTelefoneCadastroFornecedor.AutoSize = true;
            this.lblTelefoneCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblTelefoneCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefoneCadastroFornecedor.Location = new System.Drawing.Point(6, 115);
            this.lblTelefoneCadastroFornecedor.Name = "lblTelefoneCadastroFornecedor";
            this.lblTelefoneCadastroFornecedor.Size = new System.Drawing.Size(74, 16);
            this.lblTelefoneCadastroFornecedor.TabIndex = 3;
            this.lblTelefoneCadastroFornecedor.Text = "Telefone:";
            // 
            // txtNomeCadastroFornecedor
            // 
            this.txtNomeCadastroFornecedor.Location = new System.Drawing.Point(125, 73);
            this.txtNomeCadastroFornecedor.Multiline = true;
            this.txtNomeCadastroFornecedor.Name = "txtNomeCadastroFornecedor";
            this.txtNomeCadastroFornecedor.Size = new System.Drawing.Size(353, 20);
            this.txtNomeCadastroFornecedor.TabIndex = 2;
            // 
            // lblNomeCadastroFornecedor
            // 
            this.lblNomeCadastroFornecedor.AutoSize = true;
            this.lblNomeCadastroFornecedor.BackColor = System.Drawing.SystemColors.Control;
            this.lblNomeCadastroFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCadastroFornecedor.Location = new System.Drawing.Point(6, 75);
            this.lblNomeCadastroFornecedor.Name = "lblNomeCadastroFornecedor";
            this.lblNomeCadastroFornecedor.Size = new System.Drawing.Size(111, 16);
            this.lblNomeCadastroFornecedor.TabIndex = 1;
            this.lblNomeCadastroFornecedor.Text = "*Razão Social:";
            // 
            // CadastroFornecedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(993, 489);
            this.Controls.Add(this.txtCod);
            this.Controls.Add(this.btnSairCadastroFornecedor);
            this.Controls.Add(this.btnGravarCadastroFornecedor);
            this.Controls.Add(this.LblCod);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CadastroFornecedor";
            this.Text = "Cadastro de Fornecedor";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtCelularCadastroFornecedor;
        public System.Windows.Forms.Label lblCelularCadastroFornecedor;
        public System.Windows.Forms.TextBox txtRGCadastroFornecedor;
        public System.Windows.Forms.Label lblRGCadastroFornecedor;
        public System.Windows.Forms.TextBox txtEmailCadastroFornecedor;
        public System.Windows.Forms.Label lblEmailCadastroFornecedor;
        public System.Windows.Forms.TextBox txtCPFCadastroFornecedor;
        public System.Windows.Forms.Label lblCPFCadastroFornecedor;
        public System.Windows.Forms.ComboBox cboUFCadastroFornecedor;
        public System.Windows.Forms.TextBox txtNumeroCadastroFornecedor;
        public System.Windows.Forms.TextBox txtCod;
        public System.Windows.Forms.Label lblNumeroCadastroFornecedor;
        public System.Windows.Forms.Button btnSairCadastroFornecedor;
        public System.Windows.Forms.Button btnGravarCadastroFornecedor;
        public System.Windows.Forms.Label LblCod;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.MaskedTextBox txtMaskCepCadastroFornecedor;
        public System.Windows.Forms.TextBox txtCidadeCadastroFornecedor;
        public System.Windows.Forms.Label LblCidadeCadastroFornecedor;
        public System.Windows.Forms.TextBox txtBairroCadastroFornecedor;
        public System.Windows.Forms.TextBox txtEnderecoCadastroFornecedor;
        public System.Windows.Forms.Label LblBairroCadastroFornecedor;
        public System.Windows.Forms.Label lblUfCadastroFornecedor;
        public System.Windows.Forms.Label lblEnderecoCadastroFornecedor;
        public System.Windows.Forms.Label lblCepCadastroFornecedor;
        public System.Windows.Forms.TextBox txtTelefoneCadastroFornecedor;
        public System.Windows.Forms.Label lblTelefoneCadastroFornecedor;
        public System.Windows.Forms.TextBox txtNomeCadastroFornecedor;
        public System.Windows.Forms.Label lblNomeCadastroFornecedor;
        public System.Windows.Forms.TextBox txtComplementoCadastroFornecedor;
        public System.Windows.Forms.Label lblComplementoCadastroFornecedor;
    }
}