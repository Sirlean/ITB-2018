﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_C_sharp
{
    public partial class BuscaProduto : Form
       
    {
      ClnProduto ObjProduto = new ClnProduto();
        ClnUtil ObjUtil = new ClnUtil();
       
        

        public BuscaProduto()
        {
            InitializeComponent();
        }

        private void BuscaProduto_Load(object sender, EventArgs e)
        {

        }

        private void btnPesquisarBuscaProduto_Click(object sender, EventArgs e)
        {
            //chama o metodo preencher a grid
            CarregaDataGrid();

        }

        private void CarregaDataGrid()
        {
            //Método Listar que passa o parâmetro do texto digitado para o grid
            dgvBuscaProduto.DataSource = ObjProduto.LocalizarPorNome(txtDescricaoBuscaProduto.Text);
            //Cria os cabeçalhos de cada coluna 
            dgvBuscaProduto.Columns[0].HeaderText = ("Tipo"); //Nome do cabeçalho das colunas 
            dgvBuscaProduto.Columns[1].HeaderText = ("Nome");
            dgvBuscaProduto.Columns[2].HeaderText = ("Gênero");
            dgvBuscaProduto.Columns[3].HeaderText = ("Faixa Etária");

            dgvBuscaProduto.AutoResizeColumns();
        }

        private void btnNovoBuscaProduto_Click(object sender, EventArgs e)
        {
            CadastroDeProduto objCadastroDeProduto = new CadastroDeProduto();
            //objCadastroDeProduto.ShowDialog();

            
            
            ////Cria objeto do outro frmulário
            //BuscaProduto  ObjCadastroDeProduto = new BuscaProduto();

            ////Alterar as propriedades do outro form:
            objCadastroDeProduto.Text = ">>>Novo cadastro<<<";
            //ObjCadastroDeProduto.txtCod.Enabled = false;

            ////Apresenta o formulário
            objCadastroDeProduto.ShowDialog();
            ////No fechamento do frmCompleto:preencher a grid
            CarregaDataGrid();
        }

        private void btnConsultarBuscaProduto_Click(object sender, EventArgs e)
        {

            //BuscaProduto ObjCadastroDeProduto = new BuscaProduto();
            //ObjCadastroDeProduto.Text = ">>> Consultar<<<";
            //ObjCadastroDeProduto.btnGravar.Visible = false;
            //ObjCadastroDeProduto.txtTipoCadastrodeProduto.Enabled = false;
            //ObjCadastroDeProduto.txtNomeCadastrodeProduto.Enabled = false;
            //ObjCadastroDeProduto.txtGeneroCadastrodeProduto.Enabled = false;
            //ObjCadastroDeProduto.txtMaskCepCadastroFornecedor.Enabled = false;
            //ObjCadastroDeProduto.txtNomeCadastroCliente.Enabled = false;
            //ObjCadastroDeProduto.txtNumeroCadastroFornecedor.Enabled = false;
            //ObjCadastroDeProduto.txtTelefoneCadastroFornecedor.Enabled = false;
            //ObjCadastroDeProduto.cboUFCadastroCliente.Enabled = false;

            ////================================================
            //ObjCadastroAgenda.cboUFCadastroCliente.DropDownStyle = ComboBoxStyle.DropDownList;
            //ObjCadastroAgenda.txtCod.Enabled = false;
            //ObjCadastroAgenda.ShowDialog();
            //CarregaDataGrid();
        }

        private void btnAlterarBuscaProduto_Click(object sender, EventArgs e)
        {



            //Cria objeto do formulário frmCompleto
            CadastroDeProduto ObjCadastroDeProduto = new CadastroDeProduto();

            //Alterar o nome na barra de título do frmCompleto:
            ObjCadastroDeProduto.Text = ">>>Alterar<<<";
            //Desativa o texto do código
            //ObjCadastroDeProduto.txtCod.Enabled = false;
            //Alterar o texto do botão &Gravar
            //Envia para o campo Código: O valor do codigo marcado no Grid abaixo
            ObjCadastroDeProduto.btnGravarCadastroDeProduto.Text = "&Alterar";
            //Código atual
            ObjCadastroDeProduto.btnGravarCadastroDeProduto.Text = Convert.ToString(dgvBuscaProduto.CurrentRow.Cells[0].Value);
            ObjCadastroDeProduto.txtNomeCadastroDeProduto.Focus();
            ObjCadastroDeProduto.ShowDialog();
            CarregaDataGrid();
        }

        private void btnExcluirBuscaProduto_Click(object sender, EventArgs e)
        {
            CadastroDeProduto objCadastroDeProduto = new CadastroDeProduto();
            objCadastroDeProduto.ShowDialog();
        }
    }
}
