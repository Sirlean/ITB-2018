---criar data Base


create DataBase LojaJogos_01
go
use LojaJogos_01
go

Create table Tb_TipoProduto (
	Cd_TipoProduto int identity (1,1) Primary key,
	ds_TipoProduto varchar (20) not null, 
	Ativo bit not null default(1)
);
go



insert into Tb_TipoProduto values ('Jogo',1),('Console',1),('Controle',1),('HeadSet',1);

go
select * from Tb_TipoProduto
go

create table tb_Fornecedor(cd_Fornecedor int identity(1,1) primary key, ds_Fornecedor  varchar(100) not null, Cnpj varchar(14) not null,  NomeFantasia varchar (100) not null, RazaoSocial varchar (100) not null, Telefone varchar (10) not null,  Celular varchar(11) not null, Email varchar (30) not null, Cep varchar (8), Endereco varchar (20) not null, EndNumero varchar (20) not null, EndComplemento varchar (10) null, Bairro varchar (20) not null,  Cidade varchar (20)not null, UF char (2)not null, DataInclusao Date default(getdate()) not null,Ativo bit not null default(1));
go

Insert into tb_Fornecedor (ds_Fornecedor, Cnpj, NomeFantasia, RazaoSocial, Telefone, Celular, Email, Cep, Endereco, EndNumero, EndComplemento, Bairro, Cidade, UF) values 
('Carrefour','99999999999999','Carrefour','CARREFOUR COMERCIO E INDUSTRIA LTDA.','41945590','994993860','vendas@carrefour.com.br','06435200','Av Bola','100','BL01','Jd California','Barueri','SP'),
('Wallmart','88888888888888','Wallmart','WAL-MART BRASIL LTDA.','41945591','994993861','vendas@walmart.com.br','06435201','Av Bola','200','BL02','Jd California','Barueri','SP'),
('UZ Games','77777777777777','UZ Games','N C GAMES & ARCADES COM IMP EXP E L LTDA.','41945592','994993862','vendas@uzgames.com.br','06435202','Av Bola','300','BL03','Jd California','Barueri','SP'),
('Sony','66666666666666','Sony','SONY BRASIL LTDA.','41945593','994993863','vendas@sony.com.br','06435203','Av Bola','400','BL04','Jd California','Barueri','SP'),
('Microsoft','55555555555555','Microsoft','MICROSOFT INFORMATICA LTDA.','41945594','994993864','vendas@microsoft.com.br','06435204','Av Bola','500','BL05','Jd California','Barueri','SP'),
('ShopB','44444444444444','ShopB','SHOP B COMERCIO VIRTUAL LTDA.','41945595','994993865','vendas@shopb.com.br','06435205','Av Bola','600','BL06','Jd California','Barueri','SP');
go

Select * from tb_Fornecedor where Ativo = 1;
go

select cd_fornecedor, ds_Fornecedor, Cnpj, NomeFantasia, RazaoSocial, Telefone, Celular, Email from Tb_fornecedor


--drop table tb_fornecedor












 go

 --create table Tb_Produto(
 --)


-- ,
--    CONSTRAINT FK_Tb_TipoProduto_Tb_Produto FOREIGN KEY (Cd_TipoProduto)
--    REFERENCES Tb_TipoProduto(Cd_TipoProduto)
--);